//
//  ContentView.swift
//  Crazy-Week-10
//
//  Created by Troy Sawtelle on 10/23/22.
//

import SwiftUI
import SpriteKit

let cardScale = 0.06;

class GameScene:SKScene
{
    override func sceneDidLoad()
    {
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame);
        
        let discard1 = SKTexture(imageNamed: "Deck-Empty-Space")
        let discard1Array:Array<SKTexture> = [discard1]
        let discardPile1:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        discardPile1.texture = discard1;
        discardPile1.xScale = cardScale;
        discardPile1.yScale = cardScale;
        discardPile1.position = CGPoint(x: 35, y: 720);
        addChild(discardPile1);

        let discard2 = SKTexture(imageNamed: "Deck-Empty-Space")
        let discard2Array:Array<SKTexture> = [discard2]
        let discardPile2:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        discardPile2.texture = discard2;
        discardPile2.xScale = cardScale;
        discardPile2.yScale = cardScale;
        discardPile2.position = CGPoint(x: 80, y: 720);
        addChild(discardPile2);

        let discard3 = SKTexture(imageNamed: "Deck-Empty-Space")
        let discard3Array:Array<SKTexture> = [discard3]
        let discardPile3:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        discardPile3.texture = discard3;
        discardPile3.xScale = cardScale;
        discardPile3.yScale = cardScale;
        discardPile3.position = CGPoint(x: 125, y: 720);
        addChild(discardPile3);

        let discard4 = SKTexture(imageNamed: "Deck-Empty-Space")
        let discard4Array:Array<SKTexture> = [discard4]
        let discardPile4:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        discardPile4.texture = discard4;
        discardPile4.xScale = cardScale;
        discardPile4.yScale = cardScale;
        discardPile4.position = CGPoint(x: 170, y: 720);
        addChild(discardPile4);

        let spare1 = SKTexture(imageNamed: "Deck-Empty-Space")
        let spare1Array:Array<SKTexture> = [spare1]
        let sparePile1:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        sparePile1.texture = spare1;
        sparePile1.xScale = cardScale;
        sparePile1.yScale = cardScale;
        sparePile1.position = CGPoint(x: 260, y: 720);
        addChild(sparePile1);

        let spare2 = SKTexture(imageNamed: "Deck-Empty-Space")
        let spare2Array:Array<SKTexture> = [spare2]
        let sparePile2:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        sparePile2.texture = spare2;
        sparePile2.xScale = cardScale;
        sparePile2.yScale = cardScale;
        sparePile2.position = CGPoint(x: 305, y: 720);
        addChild(sparePile2);

        let spare3 = SKTexture(imageNamed: "Deck-Empty-Space")
        let spare3Array:Array<SKTexture> = [spare3]
        let sparePile3:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        sparePile3.texture = spare3;
        sparePile3.xScale = cardScale;
        sparePile3.yScale = cardScale;
        sparePile3.position = CGPoint(x: 350, y: 720);
        addChild(sparePile3);

        let play1 = SKTexture(imageNamed: "Deck-Empty-Space")
        let play1Array:Array<SKTexture> = [play1]
        let playPile1:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        playPile1.texture = play1;
        playPile1.xScale = cardScale;
        playPile1.yScale = cardScale;
        playPile1.position = CGPoint(x: 60, y: 640);
        addChild(playPile1);

        let play2 = SKTexture(imageNamed: "Deck-Empty-Space")
        let play2Array:Array<SKTexture> = [play2]
        let playPile2:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        playPile2.texture = play2;
        playPile2.xScale = cardScale;
        playPile2.yScale = cardScale;
        playPile2.position = CGPoint(x: 105, y: 640);
        addChild(playPile2);

        let play3 = SKTexture(imageNamed: "Deck-Empty-Space")
        let play3Array:Array<SKTexture> = [play3]
        let playPile3:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        playPile3.texture = play3;
        playPile3.xScale = cardScale;
        playPile3.yScale = cardScale;
        playPile3.position = CGPoint(x: 150, y: 640);
        addChild(playPile3);

        let play4 = SKTexture(imageNamed: "Deck-Empty-Space")
        let play4Array:Array<SKTexture> = [play4]
        let playPile4:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        playPile4.texture = play4;
        playPile4.xScale = cardScale;
        playPile4.yScale = cardScale;
        playPile4.position = CGPoint(x: 195, y: 640);
        addChild(playPile4);

        let play5 = SKTexture(imageNamed: "Deck-Empty-Space")
        let play5Array:Array<SKTexture> = [play5]
        let playPile5:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        playPile5.texture = play5;
        playPile5.xScale = cardScale;
        playPile5.yScale = cardScale;
        playPile5.position = CGPoint(x: 240, y: 640);
        addChild(playPile5);

        let play6 = SKTexture(imageNamed: "Deck-Empty-Space")
        let play6Array:Array<SKTexture> = [play6]
        let playPile6:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        playPile6.texture = play6;
        playPile6.xScale = cardScale;
        playPile6.yScale = cardScale;
        playPile6.position = CGPoint(x: 285, y: 640);
        addChild(playPile6);

        var play7 = SKTexture(imageNamed: "Deck-Empty-Space")
        var play7Array:Array<SKTexture> = [play7]
        var playPile7:SKSpriteNode = SKSpriteNode(imageNamed: "Deck-Empty-Space");
        playPile7.texture = play7;
        playPile7.xScale = cardScale;
        playPile7.yScale = cardScale;
        playPile7.position = CGPoint(x: 330, y: 640);
        addChild(playPile7);
    }
    

}

struct ContentView: View
{
    var scene:SKScene
    {
        let scene = GameScene();
        scene.scaleMode = .resizeFill;
        scene.backgroundColor = SKColor.systemGreen
        return scene;
        
    }
    
    var body: some View
    {
        SpriteView(scene: scene)
    }
     
    
    init() {
        
    }
    
}

struct ContentView_Previews: PreviewProvider
{
    static var previews: some View
    {
        ContentView()
    }
}

public func DefineBoard()
{
}

struct cardInfo
{
    var cardSuit = String()
    var cardName = String()
    var cardValue = Int()
    var cardFace = String()
    var cardLocation = String()
}

public func InitializeDeck()
{
    var cardDeck:Array<cardInfo> = [];
    
    var tempName = String();
    var tempValue = Int();
    
    for tempCount in 0 ... 12
    {
        let tempValue = tempCount + 1;
        switch (tempValue)
        {
            case 1: cardDeck.append(cardInfo(cardSuit: "Spades", cardName: "A", cardValue: tempValue));
            case 11: cardDeck.append(cardInfo(cardSuit: "Spades", cardName: "J", cardValue: tempValue));
            case 12: cardDeck.append(cardInfo(cardSuit: "Spades", cardName: "Q", cardValue: tempValue));
            case 13: cardDeck.append(cardInfo(cardSuit: "Spades", cardName: "K", cardValue: tempValue));
            default: cardDeck.append(cardInfo(cardSuit: "Spades", cardName: "\(tempValue)", cardValue: tempValue));
        }
    }

    for tempCount in 0 ... 12
    {
        let tempValue = tempCount + 1;
        switch (tempValue)
        {
            case 1: cardDeck.append(cardInfo(cardSuit: "Hearts", cardName: "A", cardValue: tempValue));
            case 11: cardDeck.append(cardInfo(cardSuit: "Hearts", cardName: "J", cardValue: tempValue));
            case 12: cardDeck.append(cardInfo(cardSuit: "Hearts", cardName: "Q", cardValue: tempValue));
            case 13: cardDeck.append(cardInfo(cardSuit: "Hearts", cardName: "K", cardValue: tempValue));
            default: cardDeck.append(cardInfo(cardSuit: "Hearts", cardName: "\(tempValue)", cardValue: tempValue));
        }
    }
    
    for tempCount in 0 ... 12
    {
        let tempValue = tempCount + 1;
        switch (tempValue)
        {
            case 1: cardDeck.append(cardInfo(cardSuit: "Clubs", cardName: "A", cardValue: tempValue));
            case 11: cardDeck.append(cardInfo(cardSuit: "Clubs", cardName: "J", cardValue: tempValue));
            case 12: cardDeck.append(cardInfo(cardSuit: "Clubs", cardName: "Q", cardValue: tempValue));
            case 13: cardDeck.append(cardInfo(cardSuit: "Clubs", cardName: "K", cardValue: tempValue));
            default: cardDeck.append(cardInfo(cardSuit: "Clubs", cardName: "\(tempValue)", cardValue: tempValue));
        }
    }

    for tempCount in 0 ... 12
    {
        let tempValue = tempCount + 1;
        switch (tempValue)
        {
            case 1: cardDeck.append(cardInfo(cardSuit: "Diamonds", cardName: "A", cardValue: tempValue));
            case 11: cardDeck.append(cardInfo(cardSuit: "Diamonds", cardName: "J", cardValue: tempValue));
            case 12: cardDeck.append(cardInfo(cardSuit: "Diamonds", cardName: "Q", cardValue: tempValue));
            case 13: cardDeck.append(cardInfo(cardSuit: "Diamonds", cardName: "K", cardValue: tempValue));
            default: cardDeck.append(cardInfo(cardSuit: "Diamonds", cardName: "\(tempValue)", cardValue: tempValue));
        }
    }
    
    cardDeck.shuffle();
}



