//
//  Crazy_Week_10App.swift
//  Crazy-Week-10
//
//  Created by Troy Sawtelle on 10/23/22.
//

import SwiftUI

@main
struct Crazy_Week_10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
